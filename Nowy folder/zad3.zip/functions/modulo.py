class modulo:
    def __init__(self):
        pass
    def value(self,x:float):
        return abs(x)